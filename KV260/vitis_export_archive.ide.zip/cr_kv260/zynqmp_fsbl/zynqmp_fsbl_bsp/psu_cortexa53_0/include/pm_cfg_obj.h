/******************************************************************************
* Copyright (c) 2017 - 2020 Xilinx, Inc.  All rights reserved.
* SPDX-License-Identifier: MIT
******************************************************************************/


#ifndef _PM_CFG_OBJ_H_
#define _PM_CFG_OBJ_H_

#include "xil_types.h"

#ifdef __cplusplus
extern "C" {
#endif

extern const u32 XPm_ConfigObject[];

#ifdef __cplusplus
}
#endif

#endif /* _PM_CFG_OBJ_H_ */
