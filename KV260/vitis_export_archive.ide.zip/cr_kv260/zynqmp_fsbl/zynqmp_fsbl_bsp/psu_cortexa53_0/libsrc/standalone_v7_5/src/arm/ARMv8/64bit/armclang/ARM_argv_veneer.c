/* Stub call for argv veneer */
void __ARM_argv_veneer(void) {};
